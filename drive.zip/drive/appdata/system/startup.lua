--[[pod_format="raw",created="2024-07-05 00:30:29",modified="2024-07-05 00:30:29",revision=1]]

 create_process("/appdata/369/picophone.p64.png", {window_attribs = {workspace = "tooltray", x=180, y=25, width=127, height=205}})